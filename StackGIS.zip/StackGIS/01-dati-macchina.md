Provider: Contabo
Nome server: gisserver (vmi2264216)
Piano: VPS 1 SSD (400 GB, EU datacenter)
OS: Linux Debian 13
IP pubblico: 109.199.109.228
Data creazione: 09/11/2024
